# Gojo Moveset (Forge 1.20.1)

Controls
- G             - toggle Six Eyes (rebindable in Controls -> "Gojo Moveset")
- 1 / 2 / 3 / 4 - Lapse Blue / Reversal Red / Rapid Punches / Twofold Kick (only while Six Eyes is on)

Build (GitHub, no local setup)
- Push this folder to a GitHub repo -> Actions tab -> "Build mod" -> download artifact `gojomod-jar` (a zip with the jar inside).

Build (locally)
1. Copy `gradlew`, `gradlew.bat` and the `gradle/` folder from the official Forge 1.20.1 MDK
   (files.minecraftforge.net) into this folder.
2. `./gradlew build`  ->  the jar appears in `build/libs/`
3. Put the jar into `mods/` of a Forge 1.20.1 install (client AND server for multiplayer).
   For testing: `./gradlew runClient`.

Tweaking
- All damage / cooldown / range numbers live in `ability/GojoAbilities.java`.
- The HUD panel is `client/SixEyesOverlay.java`.
