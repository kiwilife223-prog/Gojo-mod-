package dev.gojomod;

import com.mojang.logging.LogUtils;
import dev.gojomod.net.Net;
import net.minecraftforge.fml.common.Mod;
import org.slf4j.Logger;

@Mod(GojoMod.MODID)
public class GojoMod {
    public static final String MODID = "gojomod";
    public static final Logger LOGGER = LogUtils.getLogger();

    public GojoMod() {
        Net.register();
    }
}
