package dev.gojomod.ability;

import dev.gojomod.GojoMod;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.List;

/** Tiny server-side "run this in N ticks" helper. */
@Mod.EventBusSubscriber(modid = GojoMod.MODID)
public final class Scheduler {
    private static final class Task {
        int delay;
        final Runnable action;

        Task(int delay, Runnable action) {
            this.delay = delay;
            this.action = action;
        }
    }

    private static final List<Task> TASKS = new ArrayList<>();

    private Scheduler() {}

    public static void schedule(int delayTicks, Runnable action) {
        TASKS.add(new Task(Math.max(1, delayTicks), action));
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || TASKS.isEmpty()) return;
        List<Task> snapshot = new ArrayList<>(TASKS);
        for (Task t : snapshot) {
            if (--t.delay <= 0) {
                TASKS.remove(t);
                try {
                    t.action.run();
                } catch (Exception ex) {
                    GojoMod.LOGGER.error("Scheduled ability task failed", ex);
                }
            }
        }
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        TASKS.clear();
    }
}
