package dev.gojomod.ability;

import dev.gojomod.GojoMod;
import dev.gojomod.net.Net;
import dev.gojomod.net.Packets;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Server-side logic for the four Gojo moves. All numbers are easy to tweak here. */
@Mod.EventBusSubscriber(modid = GojoMod.MODID)
public final class GojoAbilities {

    public enum Ability {
        LAPSE_BLUE("Lapse Blue", true, 160),
        REVERSAL_RED("Reversal Red", false, 240),
        RAPID_PUNCHES("Rapid Punches", true, 200),
        TWOFOLD_KICK("Twofold Kick", true, 180);

        public final String displayName;
        public final boolean needsTarget;
        public final int cooldownTicks;

        Ability(String displayName, boolean needsTarget, int cooldownTicks) {
            this.displayName = displayName;
            this.needsTarget = needsTarget;
            this.cooldownTicks = cooldownTicks;
        }

        public static Ability byIndex(int i) {
            Ability[] v = values();
            return i >= 0 && i < v.length ? v[i] : null;
        }
    }

    private static final DustParticleOptions BLUE_DUST =
            new DustParticleOptions(new Vector3f(0.25f, 0.55f, 1.0f), 1.4f);
    private static final DustParticleOptions RED_DUST =
            new DustParticleOptions(new Vector3f(1.0f, 0.15f, 0.15f), 1.6f);

    private static final Set<UUID> ACTIVE = new HashSet<>();
    private static final Map<UUID, long[]> READY_AT = new HashMap<>();

    private GojoAbilities() {}

    // ------------------------------------------------------------------ state

    public static void setActive(ServerPlayer p, boolean active) {
        if (active) ACTIVE.add(p.getUUID());
        else ACTIVE.remove(p.getUUID());
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        UUID id = event.getEntity().getUUID();
        ACTIVE.remove(id);
        READY_AT.remove(id);
    }

    public static void use(ServerPlayer p, int index) {
        Ability a = Ability.byIndex(index);
        if (a == null || !ACTIVE.contains(p.getUUID()) || !p.isAlive() || p.isSpectator()) return;

        long now = p.level().getGameTime();
        long[] ready = READY_AT.computeIfAbsent(p.getUUID(), k -> new long[4]);
        if (now < ready[index]) return;

        boolean ok = switch (a) {
            case LAPSE_BLUE -> lapseBlue(p);
            case REVERSAL_RED -> reversalRed(p);
            case RAPID_PUNCHES -> rapidPunches(p);
            case TWOFOLD_KICK -> twofoldKick(p);
        };

        if (!ok) {
            p.displayClientMessage(Component.literal("No target in sight"), true);
            return;
        }

        ready[index] = now + a.cooldownTicks;
        Net.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), new Packets.Cooldown(index, a.cooldownTicks));
    }

    // -------------------------------------------------------------- abilities

    /** Pulls everything around the target into one point, then crushes it. */
    private static boolean lapseBlue(ServerPlayer p) {
        LivingEntity target = findTarget(p, 30);
        if (target == null) return false;

        ServerLevel level = lvl(p);
        final Vec3 center = target.position().add(0, target.getBbHeight() / 2.0, 0);
        level.playSound(null, p.blockPosition(), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.0f, 1.6f);

        final int duration = 20;
        for (int i = 0; i < duration; i++) {
            final int tick = i;
            Scheduler.schedule(i + 1, () -> {
                // swirl of particles shrinking towards the center
                double radius = 3.0 * (1.0 - tick / (double) duration) + 0.3;
                for (int k = 0; k < 12; k++) {
                    double ang = tick * 0.5 + k * Math.PI * 2 / 12.0;
                    level.sendParticles(BLUE_DUST,
                            center.x + Math.cos(ang) * radius,
                            center.y + ((k % 3) - 1) * 0.4,
                            center.z + Math.sin(ang) * radius,
                            1, 0, 0, 0, 0);
                }
                // pull
                AABB box = new AABB(center, center).inflate(6);
                for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, x -> x != p && x.isAlive())) {
                    Vec3 to = center.subtract(e.position().add(0, e.getBbHeight() / 2.0, 0));
                    if (to.lengthSqr() < 0.25) continue;
                    push(e, e.getDeltaMovement().scale(0.6).add(to.normalize().scale(0.35)));
                }
                // crush at the end
                if (tick == duration - 1) {
                    level.sendParticles(ParticleTypes.END_ROD, center.x, center.y, center.z, 40, 0.6, 0.6, 0.6, 0.15);
                    level.playSound(null, p.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 0.8f, 1.8f);
                    for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(center, center).inflate(3),
                            x -> x != p && x.isAlive())) {
                        hit(p, e, 4.0f);
                    }
                }
            });
        }
        return true;
    }

    /** Red projectile that explodes (no block damage) and blasts entities away. */
    private static boolean reversalRed(ServerPlayer p) {
        ServerLevel level = lvl(p);
        final Vec3 dest = aimPoint(p, 30);
        final Vec3 start = p.getEyePosition().add(p.getLookAngle().scale(1.0));
        final Vec3 line = dest.subtract(start);
        final int steps = Math.max(1, (int) Math.ceil(line.length() / 3.0));

        level.playSound(null, p.blockPosition(), SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS, 1.2f, 0.6f);

        for (int s = 1; s <= steps; s++) {
            final int st = s;
            Scheduler.schedule(s, () -> {
                Vec3 pos = start.add(line.scale(st / (double) steps));
                level.sendParticles(RED_DUST, pos.x, pos.y, pos.z, 18, 0.15, 0.15, 0.15, 0);
            });
        }

        Scheduler.schedule(steps + 1, () -> {
            level.sendParticles(ParticleTypes.EXPLOSION, dest.x, dest.y, dest.z, 3, 0.8, 0.8, 0.8, 0);
            level.sendParticles(RED_DUST, dest.x, dest.y, dest.z, 120, 1.4, 1.4, 1.4, 0.05);
            level.playSound(null, dest.x, dest.y, dest.z, SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 1.2f, 1.2f);

            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(dest, dest).inflate(4.5),
                    x -> x != p && x.isAlive())) {
                Vec3 center = e.position().add(0, e.getBbHeight() / 2.0, 0);
                double d = center.distanceTo(dest);
                hit(p, e, (float) Math.max(3.0, 9.0 - d * 1.2));
                Vec3 dir = center.subtract(dest);
                dir = dir.lengthSqr() < 1.0E-4 ? p.getLookAngle() : dir.normalize();
                push(e, dir.scale(1.6).add(0, 0.5, 0));
            }
        });
        return true;
    }

    /** Dash to the target and land a flurry of fast hits, ending with a heavy one. */
    private static boolean rapidPunches(ServerPlayer p) {
        final LivingEntity t = findTarget(p, 10);
        if (t == null) return false;

        ServerLevel level = lvl(p);
        dash(p, t);
        level.playSound(null, p.blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 1.0f, 1.3f);

        final int punches = 6;
        for (int i = 0; i < punches; i++) {
            final int n = i;
            Scheduler.schedule(4 + i * 2, () -> {
                if (!p.isAlive() || !t.isAlive() || p.distanceToSqr(t) > 36) return;
                if (p.distanceTo(t) > 2.5f) dash(p, t);

                hit(p, t, 2.5f);
                boolean last = n == punches - 1;
                Vec3 away = horizontalDir(p, t);
                push(t, away.scale(last ? 1.4 : 0.15).add(0, last ? 0.3 : 0, 0));

                level.sendParticles(ParticleTypes.CRIT, t.getX(), t.getY() + t.getBbHeight() * 0.6, t.getZ(),
                        8, 0.3, 0.3, 0.3, 0.2);
                level.playSound(null, t.blockPosition(), SoundEvents.PLAYER_ATTACK_STRONG, SoundSource.PLAYERS,
                        1.0f, 1.0f + n * 0.05f);
                p.swing(n % 2 == 0 ? InteractionHand.MAIN_HAND : InteractionHand.OFF_HAND, true);
            });
        }
        return true;
    }

    /** First kick launches the target up, second kick slams it back down. */
    private static boolean twofoldKick(ServerPlayer p) {
        final LivingEntity t = findTarget(p, 10);
        if (t == null) return false;

        ServerLevel level = lvl(p);
        dash(p, t);

        Scheduler.schedule(4, () -> {
            if (!p.isAlive() || !t.isAlive() || p.distanceToSqr(t) > 49) return;
            hit(p, t, 3.0f);
            push(t, horizontalDir(p, t).scale(0.3).add(0, 1.1, 0));
            push(p, new Vec3(p.getDeltaMovement().x * 0.2, 0.9, p.getDeltaMovement().z * 0.2));
            level.sendParticles(ParticleTypes.CRIT, t.getX(), t.getY() + 0.5, t.getZ(), 15, 0.3, 0.3, 0.3, 0.3);
            level.playSound(null, t.blockPosition(), SoundEvents.PLAYER_ATTACK_KNOCKBACK, SoundSource.PLAYERS, 1.2f, 0.9f);
            p.swing(InteractionHand.MAIN_HAND, true);
        });

        Scheduler.schedule(16, () -> {
            if (!p.isAlive() || !t.isAlive() || p.distanceToSqr(t) > 100) return;
            hit(p, t, 5.0f);
            push(t, horizontalDir(p, t).scale(0.4).add(0, -2.0, 0));
            level.sendParticles(ParticleTypes.POOF, t.getX(), t.getY() + 0.5, t.getZ(), 25, 0.4, 0.4, 0.4, 0.1);
            level.playSound(null, t.blockPosition(), SoundEvents.PLAYER_ATTACK_KNOCKBACK, SoundSource.PLAYERS, 1.4f, 0.6f);
            p.swing(InteractionHand.OFF_HAND, true);
        });
        return true;
    }

    // ---------------------------------------------------------------- helpers

    private static ServerLevel lvl(ServerPlayer p) {
        return (ServerLevel) p.level();
    }

    private static void push(Entity e, Vec3 velocity) {
        e.setDeltaMovement(velocity);
        e.hurtMarked = true;
    }

    private static void hit(ServerPlayer p, LivingEntity target, float damage) {
        target.invulnerableTime = 0; // allow rapid consecutive hits
        target.hurt(p.damageSources().playerAttack(p), damage);
    }

    private static void dash(ServerPlayer p, LivingEntity t) {
        Vec3 flat = new Vec3(t.getX() - p.getX(), 0, t.getZ() - p.getZ());
        if (flat.lengthSqr() < 1.0E-4) return;
        double speed = Math.min(1.6, flat.length() * 0.4 + 0.3);
        push(p, flat.normalize().scale(speed).add(0, 0.15, 0));
    }

    private static Vec3 horizontalDir(ServerPlayer p, LivingEntity t) {
        Vec3 v = new Vec3(t.getX() - p.getX(), 0, t.getZ() - p.getZ());
        if (v.lengthSqr() < 1.0E-4) {
            Vec3 look = p.getLookAngle();
            v = new Vec3(look.x, 0, look.z);
            if (v.lengthSqr() < 1.0E-4) return Vec3.ZERO;
        }
        return v.normalize();
    }

    private static Vec3 aimPoint(ServerPlayer p, double range) {
        LivingEntity t = findTarget(p, range);
        if (t != null) return t.position().add(0, t.getBbHeight() / 2.0, 0);
        HitResult hr = p.pick(range, 1.0f, false);
        return hr.getLocation();
    }

    /** First living entity under the crosshair within range (with line of sight). */
    private static LivingEntity findTarget(ServerPlayer p, double range) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getViewVector(1.0f);
        Vec3 end = eye.add(look.scale(range));
        AABB box = p.getBoundingBox().expandTowards(look.scale(range)).inflate(1.0);

        EntityHitResult hit = ProjectileUtil.getEntityHitResult(p.level(), p, eye, end, box,
                e -> e instanceof LivingEntity && e != p && e.isAlive() && !e.isSpectator());
        if (hit == null) return null;
        Entity e = hit.getEntity();
        return (e instanceof LivingEntity le && p.hasLineOfSight(le)) ? le : null;
    }
}
