package dev.gojomod.net;

import dev.gojomod.GojoMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class Net {
    private static final String PROTOCOL = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(GojoMod.MODID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private static boolean registered;

    private Net() {}

    public static void register() {
        if (registered) return;
        registered = true;
        int id = 0;
        CHANNEL.registerMessage(id++, Packets.Toggle.class,
                Packets.Toggle::encode, Packets.Toggle::decode, Packets.Toggle::handle);
        CHANNEL.registerMessage(id++, Packets.Use.class,
                Packets.Use::encode, Packets.Use::decode, Packets.Use::handle);
        CHANNEL.registerMessage(id++, Packets.Cooldown.class,
                Packets.Cooldown::encode, Packets.Cooldown::decode, Packets.Cooldown::handle);
    }
}
