package dev.gojomod.net;

import dev.gojomod.ability.GojoAbilities;
import dev.gojomod.client.ClientState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public final class Packets {
    private Packets() {}

    /** Client -> server: Six Eyes turned on/off. */
    public record Toggle(boolean active) {
        public static void encode(Toggle m, FriendlyByteBuf buf) {
            buf.writeBoolean(m.active());
        }

        public static Toggle decode(FriendlyByteBuf buf) {
            return new Toggle(buf.readBoolean());
        }

        public static void handle(Toggle m, Supplier<NetworkEvent.Context> sup) {
            NetworkEvent.Context ctx = sup.get();
            ctx.enqueueWork(() -> {
                ServerPlayer p = ctx.getSender();
                if (p != null) GojoAbilities.setActive(p, m.active());
            });
            ctx.setPacketHandled(true);
        }
    }

    /** Client -> server: use ability 0..3. */
    public record Use(int index) {
        public static void encode(Use m, FriendlyByteBuf buf) {
            buf.writeVarInt(m.index());
        }

        public static Use decode(FriendlyByteBuf buf) {
            return new Use(buf.readVarInt());
        }

        public static void handle(Use m, Supplier<NetworkEvent.Context> sup) {
            NetworkEvent.Context ctx = sup.get();
            ctx.enqueueWork(() -> {
                ServerPlayer p = ctx.getSender();
                if (p != null) GojoAbilities.use(p, m.index());
            });
            ctx.setPacketHandled(true);
        }
    }

    /** Server -> client: ability went on cooldown. */
    public record Cooldown(int index, int ticks) {
        public static void encode(Cooldown m, FriendlyByteBuf buf) {
            buf.writeVarInt(m.index());
            buf.writeVarInt(m.ticks());
        }

        public static Cooldown decode(FriendlyByteBuf buf) {
            return new Cooldown(buf.readVarInt(), buf.readVarInt());
        }

        public static void handle(Cooldown m, Supplier<NetworkEvent.Context> sup) {
            NetworkEvent.Context ctx = sup.get();
            ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                    () -> () -> ClientState.setCooldown(m.index(), m.ticks())));
            ctx.setPacketHandled(true);
        }
    }
}
