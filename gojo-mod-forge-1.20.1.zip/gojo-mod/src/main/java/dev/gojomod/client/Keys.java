package dev.gojomod.client;

import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.lwjgl.glfw.GLFW;

@OnlyIn(Dist.CLIENT)
public final class Keys {
    public static final KeyMapping TOGGLE =
            new KeyMapping("key.gojomod.toggle", GLFW.GLFW_KEY_G, "key.categories.gojomod");

    private Keys() {}
}
