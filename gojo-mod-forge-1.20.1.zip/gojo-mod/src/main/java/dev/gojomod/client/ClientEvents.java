package dev.gojomod.client;

import dev.gojomod.GojoMod;
import dev.gojomod.net.Net;
import dev.gojomod.net.Packets;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = GojoMod.MODID, value = Dist.CLIENT)
public final class ClientEvents {
    private ClientEvents() {}

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        // START phase runs before vanilla handles hotbar keys, so consuming the clicks
        // here stops keys 1-4 from switching the selected slot while Six Eyes is on.
        if (event.phase != TickEvent.Phase.START) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.screen != null) return;

        while (Keys.TOGGLE.consumeClick()) {
            ClientState.active = !ClientState.active;
            Net.CHANNEL.sendToServer(new Packets.Toggle(ClientState.active));
        }

        if (ClientState.active) {
            KeyMapping[] hotbar = mc.options.keyHotbarSlots;
            for (int i = 0; i < 4; i++) {
                while (hotbar[i].consumeClick()) {
                    Net.CHANNEL.sendToServer(new Packets.Use(i));
                }
            }
        }
    }

    @SubscribeEvent
    public static void onScroll(InputEvent.MouseScrollingEvent event) {
        if (ClientState.active && Minecraft.getInstance().screen == null) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        ClientState.reset();
    }
}
