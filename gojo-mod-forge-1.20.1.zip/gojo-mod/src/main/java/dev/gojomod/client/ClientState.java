package dev.gojomod.client;

import net.minecraft.client.Minecraft;
import net.minecraft.world.level.Level;

/** Client-side copy of the Six Eyes state and ability cooldowns. */
public final class ClientState {
    public static boolean active;

    private static final long[] READY_AT = new long[4];
    private static final int[] TOTAL = new int[4];

    private ClientState() {}

    private static long now() {
        Level l = Minecraft.getInstance().level;
        return l == null ? 0 : l.getGameTime();
    }

    public static void setCooldown(int index, int ticks) {
        if (index < 0 || index >= 4) return;
        READY_AT[index] = now() + ticks;
        TOTAL[index] = ticks;
    }

    /** 0 = ready, 1 = just used. */
    public static float remaining(int index) {
        if (index < 0 || index >= 4 || TOTAL[index] <= 0) return 0f;
        long left = READY_AT[index] - now();
        return left <= 0 ? 0f : Math.min(1f, (float) left / TOTAL[index]);
    }

    public static void reset() {
        active = false;
        for (int i = 0; i < 4; i++) {
            READY_AT[i] = 0;
            TOTAL[i] = 0;
        }
    }
}
