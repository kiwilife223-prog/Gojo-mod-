package dev.gojomod.client;

import dev.gojomod.ability.GojoAbilities.Ability;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.client.gui.overlay.ForgeGui;

/** The "Six Eyes" panel: title bar + 4 ability slots with cooldown bars. */
public final class SixEyesOverlay {
    private static final int SLOT_W = 45;
    private static final int SLOT_H = 38;
    private static final int GAP = 2;

    private SixEyesOverlay() {}

    public static void render(ForgeGui gui, GuiGraphics g, float partialTick, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (!ClientState.active || mc.options.hideGui || mc.player == null) return;

        Font font = mc.font;
        int total = 4 * SLOT_W + 3 * GAP;
        int x0 = w / 2 - total / 2;
        int y0 = h - 53 - SLOT_H; // sits above the health/armor rows

        // title bar
        g.fill(x0, y0 - 13, x0 + total, y0 - 2, 0xE000A8F0);
        g.drawCenteredString(font, "Six Eyes", w / 2, y0 - 12, 0xFFFFFFFF);

        Ability[] abilities = Ability.values();
        for (int i = 0; i < abilities.length; i++) {
            Ability a = abilities[i];
            int x = x0 + i * (SLOT_W + GAP);
            int cx = x + SLOT_W / 2;
            float remaining = ClientState.remaining(i);

            g.fill(x, y0, x + SLOT_W, y0 + SLOT_H, 0xA0101418);

            // cooldown bar along the top: fills up as the ability recharges
            g.fill(x, y0, x + SLOT_W, y0 + 3, 0xFF3A3F45);
            int filled = Math.round(SLOT_W * (1f - remaining));
            g.fill(x, y0, x + filled, y0 + 3, remaining > 0 ? 0xFF4F78B0 : 0xFF33CCFF);

            g.drawCenteredString(font, String.valueOf(i + 1), cx, y0 + 5, 0xFFFFFFFF);

            String[] parts = a.displayName.split(" ");
            small(g, font, parts[0], cx, y0 + 16, 0xFFE6E6E6);
            if (parts.length > 1) small(g, font, parts[1], cx, y0 + 23, 0xFFE6E6E6);
            if (a.needsTarget) small(g, font, "TARGET", cx, y0 + 30, 0xFF9AD8FF);
        }
    }

    private static void small(GuiGraphics g, Font font, String text, int cx, int y, int color) {
        float s = 0.7f;
        g.pose().pushPose();
        g.pose().scale(s, s, 1f);
        g.drawString(font, text, (int) (cx / s - font.width(text) / 2f), (int) (y / s), color, true);
        g.pose().popPose();
    }
}
